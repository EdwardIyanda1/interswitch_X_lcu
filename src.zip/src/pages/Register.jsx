import { useRef, useState } from "react";
import Header from "../components/Header.jsx";
import PrivacyDialog from "../components/PrivacyDialog.jsx";
import { FOCUS_AREAS, LEVELS } from "../config.js";
import { usePage } from "../usePage.js";

const EMPTY = { firstName: "", lastName: "", phone: "", email: "", department: "", level: "" };

function validate(v) {
  const e = {};
  if (v.firstName.trim().length < 2) e.firstName = "Enter your first name.";
  if (v.lastName.trim().length < 2) e.lastName = "Enter your last name.";
  if (!/^\+?[0-9\s-]{10,16}$/.test(v.phone.trim())) e.phone = "Enter a valid phone number.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email.trim())) e.email = "Enter a valid email address.";
  if (v.department.trim().length < 2) e.department = "Enter your department.";
  if (!v.level) e.level = "Select your level.";
  return e;
}

function Field({ id, label, error, children }) {
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      {children}
      {error && (
        <p className="field-error" id={`${id}-error`}>
          {error}
        </p>
      )}
    </div>
  );
}

export default function Register() {
  usePage("Register | Interswitch Discovery Series, Lead City University");
  const privacy = useRef(null);
  const [values, setValues] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);

  const set = (name) => (ev) => {
    setValues((p) => ({ ...p, [name]: ev.target.value }));
    if (errors[name]) setErrors((p) => ({ ...p, [name]: undefined }));
  };

  const inputProps = (name) => ({
    id: name,
    name,
    value: values[name],
    onChange: set(name),
    "aria-invalid": errors[name] ? "true" : undefined,
    "aria-describedby": errors[name] ? `${name}-error` : undefined,
  });

  async function onSubmit(ev) {
    ev.preventDefault();
    setFormError("");
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length) {
      document.getElementById(Object.keys(found)[0])?.focus();
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (data.errors) setErrors(data.errors);
        setFormError(data.error || "Something went wrong. Try again.");
        return;
      }
      setDone({ email: values.email.trim().toLowerCase(), first: values.firstName.trim(), emailSent: data.emailSent !== false });
      window.scrollTo({ top: 0 });
    } catch {
      setFormError("Could not reach the server. Check your connection and try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="shell">
      <Header />
      <main className="stage">
        <section className="intro" aria-labelledby="intro-title">
          <h1 id="intro-title">Register for the Interswitch Discovery Series</h1>
          <p className="lead">
            A programme for student builders at Lead City University, leading to the Hackathon, Pitch and Demo
            Day. Register once with your details and we will confirm by email.
          </p>
          {/* <h2 className="intro-sub">Focus areas</h2>
          {/* <ul className="focus">
            {FOCUS_AREAS.map((a) => (
              <li key={a}>{a}</li>
            ))}
          </ul> */}
        </section>

        <section className="panel" aria-labelledby="panel-title">
          {done ? (
            <div className="thanks" role="status">
              <h2 id="panel-title">Thank you for registering, {done.first}.</h2>
              {done.emailSent ? (
                <p>
                  Check your mail. We sent a confirmation to <strong>{done.email}</strong>. If it is not in your
                  inbox in a few minutes, look in your spam folder.
                </p>
              ) : (
                <p>
                  Your registration is saved, but we could not send the confirmation email to{" "}
                  <strong>{done.email}</strong> just now. The organisers will contact you at that address.
                </p>
              )}
              <button
                className="btn btn-secondary"
                type="button"
                onClick={() => {
                  setDone(null);
                  setValues(EMPTY);
                }}
              >
                Register another person
              </button>
            </div>
          ) : (
            <form onSubmit={onSubmit} noValidate>
              <h2 id="panel-title">Your details</h2>
              <div className="row">
                <Field id="firstName" label="First name" error={errors.firstName}>
                  <input {...inputProps("firstName")} type="text" autoComplete="given-name" />
                </Field>
                <Field id="lastName" label="Last name" error={errors.lastName}>
                  <input {...inputProps("lastName")} type="text" autoComplete="family-name" />
                </Field>
              </div>
              <Field id="phone" label="Phone number" error={errors.phone}>
                <input {...inputProps("phone")} type="tel" inputMode="tel" autoComplete="tel" />
              </Field>
              <Field id="email" label="Email address" error={errors.email}>
                <input {...inputProps("email")} type="email" autoComplete="email" />
              </Field>
              <div className="row">
                <Field id="department" label="Department" error={errors.department}>
                  <input {...inputProps("department")} type="text" />
                </Field>
                <Field id="level" label="Level" error={errors.level}>
                  <select {...inputProps("level")}>
                    <option value="">Select level</option>
                    {LEVELS.map((l) => (
                      <option key={l} value={l}>
                        {l}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>
              {formError && (
                <p className="form-error" role="alert">
                  {formError}
                </p>
              )}
              <button className="btn btn-primary" type="submit" disabled={busy}>
                {busy ? "Registering" : "Register"}
              </button>
            </form>
          )}
        </section>
      </main>
      <footer className="footer">
        <div className="footer-inner">
          <span>Interswitch Discovery Series at Lead City University, Ibadan</span>
          <span className="footer-links">
            <button type="button" className="link" onClick={() => privacy.current?.showModal()}>
              Privacy notice
            </button>
            <a href="/dashboard">Organiser login</a>
          </span>
        </div>
      </footer>
      <PrivacyDialog ref={privacy} />
    </div>
  );
}
