import { useCallback, useEffect, useMemo, useState } from "react";
import Header from "../components/Header.jsx";
import { LEVELS } from "../config.js";
import { usePage } from "../usePage.js";

const KEY = "discovery_admin_token";

function Login({ onToken }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(ev) {
    ev.preventDefault();
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return setError(data.error || "Could not sign in.");
      onToken(data.token);
    } catch {
      setError("Could not reach the server. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="plain narrow">
      <h1>Organiser sign in</h1>
      <form onSubmit={submit}>
        <div className="field">
          <label htmlFor="admin-email">Email address</label>
          <input id="admin-email" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div className="field">
          <label htmlFor="admin-password">Password</label>
          <input id="admin-password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </div>
        {error && (
          <p className="form-error" role="alert">
            {error}
          </p>
        )}
        <button className="btn btn-primary" type="submit" disabled={busy}>
          {busy ? "Signing in" : "Sign in"}
        </button>
      </form>
    </main>
  );
}

function csvCell(v) {
  return `"${String(v ?? "").replace(/"/g, '""')}"`;
}

function Table({ token, onExpired }) {
  const [rows, setRows] = useState(null);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [level, setLevel] = useState("");

  const load = useCallback(async () => {
    setError("");
    try {
      const res = await fetch("/api/registrations", { headers: { Authorization: `Bearer ${token}` } });
      if (res.status === 401) return onExpired();
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return setError(data.error || "Could not load registrations.");
      setRows(data.registrations);
    } catch {
      setError("Could not reach the server. Try again.");
    }
  }, [token, onExpired]);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    if (!rows) return [];
    const q = query.trim().toLowerCase();
    return rows.filter(
      (r) =>
        (!level || r.level === level) &&
        (!q || [r.firstName, r.lastName, r.email, r.phone, r.department].join(" ").toLowerCase().includes(q))
    );
  }, [rows, query, level]);

  const today = useMemo(() => {
    if (!rows) return 0;
    const d = new Date().toDateString();
    return rows.filter((r) => new Date(r.createdAt).toDateString() === d).length;
  }, [rows]);

  async function remove(r) {
    if (!window.confirm(`Delete the registration for ${r.firstName} ${r.lastName}?`)) return;
    const res = await fetch(`/api/registrations?id=${r.id}`, { method: "DELETE", headers: { Authorization: `Bearer ${token}` } });
    if (res.status === 401) return onExpired();
    if (res.ok) setRows((p) => p.filter((x) => x.id !== r.id));
    else setError("Could not delete that registration.");
  }

  function exportCsv() {
    const head = ["First name", "Last name", "Phone", "Email", "Department", "Level", "Registered"];
    const lines = [head.map(csvCell).join(",")].concat(
      filtered.map((r) =>
        [r.firstName, r.lastName, r.phone, r.email, r.department, r.level, new Date(r.createdAt).toISOString()].map(csvCell).join(",")
      )
    );
    const blob = new Blob(["\uFEFF" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `discovery-series-registrations-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main className="dash">
      <h1>Registrations</h1>
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
      {rows === null && !error && <p className="muted">Loading registrations</p>}
      {rows && (
        <>
          <dl className="stats">
            <div>
              <dt>Total registered</dt>
              <dd>{rows.length}</dd>
            </div>
            <div>
              <dt>Registered today</dt>
              <dd>{today}</dd>
            </div>
            <div>
              <dt>Showing</dt>
              <dd>{filtered.length}</dd>
            </div>
          </dl>

          <div className="tools">
            <div className="field grow">
              <label htmlFor="search">Search</label>
              <input id="search" type="search" placeholder="Name, email, phone or department" value={query} onChange={(e) => setQuery(e.target.value)} />
            </div>
            <div className="field">
              <label htmlFor="level-filter">Level</label>
              <select id="level-filter" value={level} onChange={(e) => setLevel(e.target.value)}>
                <option value="">All levels</option>
                {LEVELS.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </div>
            <button className="btn btn-secondary" type="button" onClick={exportCsv} disabled={!filtered.length}>
              Export CSV
            </button>
          </div>

          {filtered.length === 0 ? (
            <p className="empty">{rows.length === 0 ? "No one has registered yet. New registrations appear here." : "No registrations match this search."}</p>
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Department</th>
                    <th scope="col">Level</th>
                    <th scope="col">Registered</th>
                    <th scope="col">
                      <span className="sr-only">Actions</span>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((r) => (
                    <tr key={r.id}>
                      <td>
                        {r.firstName} {r.lastName}
                      </td>
                      <td>{r.email}</td>
                      <td>{r.phone}</td>
                      <td>{r.department}</td>
                      <td>{r.level}</td>
                      <td>{new Date(r.createdAt).toLocaleString("en-NG", { dateStyle: "medium", timeStyle: "short" })}</td>
                      <td>
                        <button className="link danger" type="button" onClick={() => remove(r)}>
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </main>
  );
}

export default function Dashboard() {
  usePage("Registrations | Discovery Series admin", { noindex: true });
  const [token, setToken] = useState(() => sessionStorage.getItem(KEY) || "");

  const save = (t) => {
    sessionStorage.setItem(KEY, t);
    setToken(t);
  };
  const clear = useCallback(() => {
    sessionStorage.removeItem(KEY);
    setToken("");
  }, []);

  return (
    <div className="shell">
      <Header
        right={
          token ? (
            <button className="btn btn-secondary btn-small" type="button" onClick={clear}>
              Sign out
            </button>
          ) : (
            <a className="link" href="/">
              Back to registration
            </a>
          )
        }
      />
      {token ? <Table token={token} onExpired={clear} /> : <Login onToken={save} />}
    </div>
  );
}
