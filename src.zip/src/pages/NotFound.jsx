import Header from "../components/Header.jsx";
import { usePage } from "../usePage.js";

export default function NotFound() {
  usePage("Page not found | Interswitch Discovery Series", { noindex: true });
  return (
    <div className="shell">
      <Header />
      <main className="plain">
        <h1>Page not found</h1>
        <p>The address you opened does not exist. Registration is on the main page.</p>
        <a className="btn btn-primary btn-link" href="/">
          Go to registration
        </a>
      </main>
    </div>
  );
}
