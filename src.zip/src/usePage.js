import { useEffect } from "react";

export function usePage(title, { noindex = false } = {}) {
  useEffect(() => {
    document.title = title;
    let meta = document.querySelector('meta[name="robots"]');
    if (noindex) {
      if (!meta) {
        meta = document.createElement("meta");
        meta.name = "robots";
        document.head.appendChild(meta);
      }
      meta.content = "noindex, nofollow";
    } else if (meta) {
      meta.remove();
    }
  }, [title, noindex]);
}
