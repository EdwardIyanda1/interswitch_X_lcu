import { forwardRef } from "react";

const PrivacyDialog = forwardRef(function PrivacyDialog(_, ref) {
  return (
    <dialog ref={ref} className="dialog" aria-labelledby="privacy-title">
      <h2 id="privacy-title">Privacy notice</h2>
      <p>
        We collect your name, phone number, email address, department and level so we can register you for the
        Interswitch Discovery Series at Lead City University and contact you about it.
      </p>
      <p>
        Your details are stored in the organisers' database and used only to run the programme, including sending
        your confirmation and later updates. They are not sold. To correct or remove your details, reply to your
        confirmation email.
      </p>
      <form method="dialog">
        <button className="btn btn-secondary" type="submit">
          Close
        </button>
      </form>
    </dialog>
  );
});

export default PrivacyDialog;
