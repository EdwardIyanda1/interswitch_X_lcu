import { LOGOS } from "../config.js";

export default function Header({ right }) {
  return (
    <header className="topbar">
      <div className="topbar-inner">
        <div className="logos">
          <img {...LOGOS.interswitch} />
          <span className="logo-divider" aria-hidden="true" />
          <img {...LOGOS.lcu} />
        </div>
        {right}
      </div>
    </header>
  );
}
